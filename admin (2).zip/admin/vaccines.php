<?php
$host = 'localhost';
$db = 'vms_db';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $person_name = $_POST['person_name'];
    $vaccine_name = $_POST['vaccine'];
    $vaccination_date = $_POST['date'];

    $check_query = "SELECT quantity FROM vaccines WHERE vaccine_name = '$vaccine_name'";
    $check_result = $conn->query($check_query);
    $row = $check_result->fetch_assoc();

    if ($row && $row['quantity'] > 0) {
        $insert_query = "INSERT INTO vaccination_records (person_name, vaccine, date) VALUES ('$person_name', '$vaccine_name', '$vaccination_date')";
        if ($conn->query($insert_query)) {
            $conn->query("UPDATE vaccines SET quantity = quantity - 1 WHERE vaccine_name = '$vaccine_name'");
            echo "<p class='success'>Vaccine assigned successfully!</p>";
        } else {
            echo "<p class='error'>Error assigning vaccine.</p>";
        }
    } else {
        echo "<p class='error'>Vaccine not available.</p>";
    }
}

$records_result = $conn->query("SELECT * FROM vaccination_records ORDER BY date DESC");
$inventory_result = $conn->query("SELECT * FROM vaccines");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccination Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }
        header {
            background-color: #007bff;
            padding: 15px;
            text-align: center;
        }
        nav {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        header a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }
        header a:hover {
            background-color: #0056b3;
            transform: scale(1.1);
        }
        header a.active {
            background-color:rgb(162, 253, 159);
            color: black;
            font-weight: bold;
        }
        h1 {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }
        form {
            background: white;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            max-width: 500px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        form label {
            display: block;
            margin: 10px 0 5px;
        }
        form input, form select, form button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        form button {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }
        form button:hover {
            background-color: #218838;
            transform: scale(1.05);
        }
        .success {
            color: green;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px auto;
            background: white;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        a {
            display: inline-block;
            margin: 10px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease-in-out, transform 0.2s ease-in-out;
        }
        a:hover {
            background-color: #0056b3;
            transform: scale(1.1);
        }
    </style>
</head>
<body>

<header>
    <nav>
        <a href="index.php">Home</a>
        <a href="Vaccine Requests.php">Vaccine Requests</a>
        <a href="vaccines.php" class="active">Vaccination Report</a>
    </nav>
</header>

<h1>Vaccination Report</h1>

<form method="POST">
    <label>Person Name: <input type="text" name="person_name" required></label>
    <label>Vaccine:
        <select name="vaccine" required>
            <?php while ($row = $inventory_result->fetch_assoc()): ?>
                <option value="<?= $row['vaccine_name'] ?>">
                    <?= $row['vaccine_name'] ?> (Available: <?= $row['quantity'] ?>)
                </option>
            <?php endwhile; ?>
        </select>
    </label>
    <label>Date: <input type="date" name="date" required></label>
    <button type="submit">Assign Vaccine</button>
</form>

<h2>Vaccination Records</h2>
<table>
    <tr>
        <th>Person Name</th>
        <th>Vaccine</th>
        <th>Date</th>
    </tr>
    <?php while ($row = $records_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['person_name'] ?></td>
            <td><?= $row['vaccine'] ?></td>
            <td><?= $row['date'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<h2>Vaccine Inventory</h2>
<table>
    <tr>
        <th>Vaccine Name</th>
        <th>Available Quantity</th>
    </tr>
    <?php $inventory_result->data_seek(0); while ($row = $inventory_result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['vaccine_name'] ?></td>
            <td><?= $row['quantity'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>

<?php $conn->close(); ?>
