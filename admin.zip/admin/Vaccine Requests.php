<?php
// Database connection (replace with your credentials)
$host = 'localhost';
$db = 'vms_db';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);

// Check for successful connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle approval/rejection of vaccine requests
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $request_id = $_GET['id'];

    // Update the status of the request based on the action (approve/reject)
    if ($action === 'approve') {
        $update_status_query = "UPDATE vaccine_requests SET status = 'Approved' WHERE id = ?";
    } elseif ($action === 'reject') {
        $update_status_query = "UPDATE vaccine_requests SET status = 'Rejected' WHERE id = ?";
    }

    $stmt = $conn->prepare($update_status_query);
    $stmt->bind_param('i', $request_id);

    // Execute the status update query
    if ($stmt->execute()) {
        echo "<p class='success'>Request $action successfully!</p>";
    } else {
        echo "<p class='error'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

// Fetch available vaccines for the dropdown (can be used for future form)
$inventory_query = "SELECT * FROM vaccines";
$inventory_result = $conn->query($inventory_query);

// Fetch vaccine requests from the database (for display and management)
$requests_query = "SELECT * FROM vaccine_requests ORDER BY request_date DESC";
$requests_result = $conn->query($requests_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccine Request - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
            line-height: 1.6;
        }

        /* Header Style */
        header {
            background-color: #007bff;
            padding: 15px;
            color: white;
            text-align: center;
        }

        header a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-size: 18px;
        }

        header a:hover {
            text-decoration: none;
        }

        /* Active link */
        header a.active {
            font-weight: bold;
            color: #ffd700; /* Golden color for active link */
        }

        /* Content Style */
        h1 {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px auto;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        .status {
            text-transform: capitalize;
        }

        a {
            display: inline-block;
            margin: 10px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<!-- Header with Navigation Links -->
<header>
    <a href="index.php">Home</a>
    <a href="vaccines.php">Vaccines</a>
    <a href="vaccine_requests.php" class="active">Vaccine Requests</a> <!-- Active link here -->
</header>

<!-- Admin Panel Content -->
<h1>Vaccine Request - Admin Panel</h1>

<!-- Display Vaccine Requests -->
<h2>Vaccine Requests</h2>
<table>
    <tr>
        <th>Requester Name</th>
        <th>Vaccine</th>
        <th>Quantity</th>
        <th>Request Date</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <!-- Dummy Data for Vaccine Requests -->
    <tr>
        <td>John Doe</td>
        <td>COVID-19 Vaccine</td>
        <td>100</td>
        <td>2024-12-15</td>
        <td class="status">Pending</td>
        <td>
            <a href="?action=approve&id=1">Approve</a>
            <a href="?action=reject&id=1">Reject</a>
        </td>
    </tr>
    <tr>
        <td>Jane Smith</td>
        <td>Flu Vaccine</td>
        <td>50</td>
        <td>2024-12-16</td>
        <td class="status">Pending</td>
        <td>
            <a href="?action=approve&id=2">Approve</a>
            <a href="?action=reject&id=2">Reject</a>
        </td>
    </tr>
    <tr>
        <td>Michael Johnson</td>
        <td>Hepatitis B Vaccine</td>
        <td>30</td>
        <td>2024-12-17</td>
        <td class="status">Pending</td>
        <td>
            <a href="?action=approve&id=3">Approve</a>
            <a href="?action=reject&id=3">Reject</a>
        </td>
    </tr>
    <!-- End of Dummy Data -->
</table>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
