<?php
// Establish connection to the database
$host = 'localhost'; // Database host
$db = 'vms_db'; // Database name
$user = 'root'; // Database user
$pass = ''; // Database password
$conn = new mysqli($host, $user, $pass, $db);

// Check for successful connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle form submission when assigning a vaccine
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form inputs
    $person_name = $_POST['person_name'] ?? '';
    $vaccine_name = $_POST['vaccine'] ?? '';
    $vaccination_date = $_POST['date'] ?? '';

    // Insert a new vaccination record into the database
    $insert_query = "INSERT INTO vaccination_records (person_name, vaccine, date) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param('sss', $person_name, $vaccine_name, $vaccination_date);

    if ($stmt->execute()) {
        // If vaccine assigned successfully, update inventory
        $update_inventory_query = "UPDATE vaccines SET quantity = quantity - 1 WHERE vaccine_name = ?";
        $update_stmt = $conn->prepare($update_inventory_query);
        $update_stmt->bind_param('s', $vaccine_name);

        if ($update_stmt->execute()) {
            echo "<p class='success'>Vaccine assigned and inventory updated successfully!</p>";
        } else {
            echo "<p class='error'>Error updating vaccine inventory: " . $update_stmt->error . "</p>";
        }

        $update_stmt->close();
    } else {
        echo "<p class='error'>Error assigning vaccine: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

// Fetch vaccination records from the database
$records_query = "SELECT * FROM vaccination_records ORDER BY date DESC";
$records_result = $conn->query($records_query);

// Fetch vaccine inventory data
$inventory_query = "SELECT * FROM vaccines";
$inventory_result = $conn->query($inventory_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccination Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
            line-height: 1.6;
        }

        /* Header Style */
        header {
            background-color: #007bff;
            padding: 15px;
            color: white;
            text-align: center;
        }

        header a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-size: 18px;
        }

        header a:hover {
            text-decoration: none;
        }

        /* Active link */
        header a.active {
            font-weight: bold;
            color: #ffd700; /* Golden color for active link */
        }

        h1 {
            background-color: #007bff;
            color: white;
            padding: 10px;
            text-align: center;
        }

        form {
            background: white;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            max-width: 500px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        form label {
            display: block;
            margin: 10px 0 5px;
        }

        form input, form button, form select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        form button {
            background-color: #28a745;
            color: white;
            border: none;
        }

        form button:hover {
            background-color: #218838;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px auto;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        a {
            display: inline-block;
            margin: 10px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<!-- Header with Navigation Links -->
<header>
    <a href="index.php">Home</a>
    <a href="vaccines.php">Vaccines</a>
    <a href="vaccine_requests.php">Vaccine Requests</a>
    <a href="vaccination_report.php" class="active">Vaccination Report</a> <!-- Active link here -->
</header>

<!-- Vaccination Report Content -->
<h1>Vaccination Report</h1>

<!-- Form to Assign Vaccine -->
<form method="POST">
    <label>Person Name: <input type="text" name="person_name" required></label>
    <label>Vaccine:
        <select name="vaccine" required>
            <?php while ($row = $inventory_result->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($row['vaccine_name']) ?>">
                    <?= htmlspecialchars($row['vaccine_name']) ?> (Available: <?= htmlspecialchars($row['quantity']) ?>)
                </option>
            <?php endwhile; ?>
        </select>
    </label>
    <label>Date: <input type="date" name="date" required></label>
    <button type="submit">Assign Vaccine</button>
</form>

<!-- Display Vaccination Records -->
<h2>Vaccination Records</h2>
<table>
    <tr>
        <th>Person Name</th>
        <th>Vaccine</th>
        <th>Date</th>
    </tr>
    <?php while ($row = $records_result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['person_name']) ?></td>
            <td><?= htmlspecialchars($row['vaccine']) ?></td>
            <td><?= htmlspecialchars($row['date']) ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<!-- Display Vaccine Inventory -->
<h2>Vaccine Inventory</h2>
<table>
    <tr>
        <th>Vaccine Name</th>
        <th>Available Quantity</th>
    </tr>
    <?php $inventory_result->data_seek(0); while ($row = $inventory_result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['vaccine_name']) ?></td>
            <td><?= htmlspecialchars($row['quantity']) ?></td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
